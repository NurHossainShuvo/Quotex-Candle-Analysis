package com.example.quotexanalysis

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Candle(val open: Double, val high: Double, val low: Double, val close: Double) {
    val body get() = abs(close - open)
    val range get() = high - low
    val upperWick get() = high - max(open, close)
    val lowerWick get() = min(open, close) - low
    val bullish get() = close > open
    val bearish get() = close < open
}

object CandleAnalysis {
    fun analyze(raw: String): String {
        val candles = raw.lines().mapNotNull { line ->
            val s = line.trim()
            if (s.isBlank() || s.startsWith("#")) null else {
                val p = s.split(",", ";", " ", "\t").filter { it.isNotBlank() }
                if (p.size != 4) throwIfBad(line) else {
                    val v = p.mapNotNull { it.toDoubleOrNull() }
                    if (v.size != 4) throwIfBad(line)
                    else {
                        val c = Candle(v[0], v[1], v[2], v[3])
                        if (c.high < max(c.open, c.close) || c.low > min(c.open, c.close) ||
                            c.high < c.low) throwIfBad(line)
                        c
                    }
                }
            }
        }
        if (candles.size < 5) return "কমপক্ষে ৫টি সঠিক OHLC candle দিন।"
        val closes = candles.map { it.close }
        val last = candles.last()
        val ema9 = ema(closes.takeLast(60), 9)
        val ema21 = ema(closes.takeLast(100), 21)
        val rsi = rsi(closes, 14)
        val recent = candles.takeLast(min(20, candles.size))
        val support = recent.minOf { it.low }
        val resistance = recent.maxOf { it.high }
        val avgRange = recent.map { it.range }.average()
        val trend = when {
            ema9 > ema21 -> "EMA bias: UP"
            ema9 < ema21 -> "EMA bias: DOWN"
            else -> "EMA bias: NEUTRAL"
        }
        val rsiText = when {
            rsi >= 70 -> "RSI overbought zone"
            rsi <= 30 -> "RSI oversold zone"
            else -> "RSI neutral zone"
        }
        val candleText = when {
            last.range <= 0 -> "Last candle invalid/flat"
            last.lowerWick > last.body * 2 && last.upperWick < last.body ->
                "Possible hammer-like candle (context required)"
            last.upperWick > last.body * 2 && last.lowerWick < last.body ->
                "Possible shooting-star-like candle (context required)"
            candles.size >= 2 && candles[candles.lastIndex - 1].bearish &&
                last.bullish && last.open <= candles[candles.lastIndex - 1].close &&
                last.close >= candles[candles.lastIndex - 1].open ->
                "Possible bullish engulfing"
            candles.size >= 2 && candles[candles.lastIndex - 1].bullish &&
                last.bearish && last.open >= candles[candles.lastIndex - 1].close &&
                last.close <= candles[candles.lastIndex - 1].open ->
                "Possible bearish engulfing"
            else -> if (last.bullish) "Last candle bullish" else if (last.bearish) "Last candle bearish" else "Last candle doji/flat"
        }
        val nearSupport = abs(last.close - support) <= max(avgRange * 0.25, 1e-9)
        val nearResistance = abs(resistance - last.close) <= max(avgRange * 0.25, 1e-9)
        val hint = when {
            nearSupport && ema9 > ema21 && rsi < 70 -> "WATCH / possible support reaction"
            nearResistance && ema9 < ema21 && rsi > 30 -> "WATCH / possible resistance reaction"
            ema9 > ema21 && rsi in 35.0..65.0 -> "UP BIAS (not a trade instruction)"
            ema9 < ema21 && rsi in 35.0..65.0 -> "DOWN BIAS (not a trade instruction)"
            else -> "WAIT — mixed/weak conditions"
        }
        return """
            Candles parsed: ${candles.size}
            Last OHLC: ${last.open}, ${last.high}, ${last.low}, ${last.close}
            $candleText
            EMA 9: ${fmt(ema9)} | EMA 21: ${fmt(ema21)}
            $trend
            RSI 14: ${fmt(rsi)} — $rsiText
            Recent support (last ${recent.size}): ${fmt(support)}
            Recent resistance (last ${recent.size}): ${fmt(resistance)}
            Average recent range: ${fmt(avgRange)}

            Analysis hint: $hint

            Confidence is not a win probability. This is rule-based analysis, not a forecast.
        """.trimIndent()
    }

    private fun throwIfBad(line: String): Nothing =
        throw IllegalArgumentException("Invalid OHLC row: $line. Format: open,high,low,close")

    private fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return Double.NaN
        val alpha = 2.0 / (period + 1.0)
        var result = values.first()
        for (v in values.drop(1)) result = alpha * v + (1 - alpha) * result
        return result
    }

    private fun rsi(closes: List<Double>, period: Int): Double {
        if (closes.size <= period) return 50.0
        var gains = 0.0
        var losses = 0.0
        for (i in 1..period) {
            val d = closes[i] - closes[i - 1]
            if (d >= 0) gains += d else losses -= d
        }
        var avgGain = gains / period
        var avgLoss = losses / period
        for (i in period + 1 until closes.size) {
            val d = closes[i] - closes[i - 1]
            avgGain = (avgGain * (period - 1) + max(d, 0.0)) / period
            avgLoss = (avgLoss * (period - 1) + max(-d, 0.0)) / period
        }
        if (avgLoss == 0.0) return if (avgGain == 0.0) 50.0 else 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    private fun fmt(v: Double) = if (v.isFinite()) "%.6f".format(java.util.Locale.US, v) else "n/a"
}
