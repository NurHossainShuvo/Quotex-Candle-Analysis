package com.example.quotexanalysis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat

/**
 * User-authorized screen capture. Frames are sampled in memory and immediately discarded.
 * This demo intentionally does not save or transmit screenshots.
 */
class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestHint = "Waiting for first frame"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, notification("Screen capture active — local only"))
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (data == null) {
                    stopCapture()
                    return START_NOT_STICKY
                }
                try {
                    val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = manager.getMediaProjection(code, data)
                    projection?.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() { stopCapture() }
                    }, android.os.Handler(mainLooper))
                    startReader()
                } catch (_: Exception) {
                    stopCapture()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startReader() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                // Very rough green/red pixel sample. Not candle recognition or OHLC extraction.
                var green = 0
                var red = 0
                val rowStep = 24
                val colStep = 24
                for (y in height / 4 until (height * 3 / 4) step rowStep) {
                    for (x in width / 5 until (width * 4 / 5) step colStep) {
                        val offset = y * rowStride + x * pixelStride
                        if (offset + 2 < buffer.limit()) {
                            val r = buffer.get(offset).toInt() and 0xff
                            val g = buffer.get(offset + 1).toInt() and 0xff
                            val b = buffer.get(offset + 2).toInt() and 0xff
                            if (g > r * 1.25 && g > b * 1.15 && g > 70) green++
                            if (r > g * 1.25 && r > b * 1.15 && r > 70) red++
                        }
                    }
                }
                latestHint = when {
                    green > red * 1.25 -> "Green pixels dominate — unreliable visual hint"
                    red > green * 1.25 -> "Red pixels dominate — unreliable visual hint"
                    else -> "Mixed colors — WAIT / inconclusive"
                }
                updateNotification("Capture active • $latestHint")
            } catch (_: Exception) {
                latestHint = "Frame could not be analyzed"
            } finally {
                image.close()
            }
        }, android.os.Handler(mainLooper))
        virtualDisplay = projection?.createVirtualDisplay(
            "QuotexLocalAnalysis", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )
    }

    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null); imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notification(text: String): Notification {
        val channelId = "capture_status"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Capture status", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Quotex Analysis")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    override fun onDestroy() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.quotexanalysis.START_CAPTURE"
        const val ACTION_STOP = "com.example.quotexanalysis.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val NOTIFICATION_ID = 4137
    }
}
