package com.example.quotexanalysis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var ohlcInput: EditText

    private val captureConsent = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, intent)
            status.text = "● Capture starting — Android system permission granted"
            Toast.makeText(this, "Capture started. You can switch to the chart.", Toast.LENGTH_LONG).show()
        } else {
            status.text = "Capture stopped / permission not granted"
        }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startConsent() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(0xFF101820.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFF1F5F9.toInt())
            setPadding(0, 8, 0, 8)
        }
        content.addView(label("Quotex Candle Analysis", 24f))
        content.addView(label("Privacy-first • Local processing • No auto-trading"))
        status = label("● Capture is OFF")
        content.addView(status)

        val start = Button(this).apply {
            text = "Start screen capture"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else startConsent()
            }
        }
        content.addView(start, fullWidth())
        content.addView(Button(this).apply {
            text = "Stop capture"
            setOnClickListener {
                startService(Intent(this@MainActivity, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
                status.text = "● Stop requested"
            }
        }, fullWidth())

        content.addView(label("Manual OHLC input", 19f))
        content.addView(label("One candle per line: open,high,low,close. Oldest first. Use decimal dot."))
        ohlcInput = EditText(this).apply {
            hint = "1.0810,1.0820,1.0800,1.0815\n1.0815,1.0830,1.0810,1.0825"
            setHintTextColor(0xFF8795A1.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF24313D.toInt())
            minLines = 5
            gravity = Gravity.TOP
            setPadding(12, 12, 12, 12)
        }
        content.addView(ohlcInput, fullWidth())
        content.addView(Button(this).apply {
            text = "Analyze OHLC"
            setOnClickListener {
                output.text = CandleAnalysis.analyze(ohlcInput.text.toString())
            }
        }, fullWidth())
        content.addView(label("Analysis result", 19f))
        output = label("Paste OHLC rows, then tap Analyze.")
        content.addView(output)
        content.addView(label(
            "Warning: screen color hints are experimental and are not a reliable prediction. " +
            "Confirm candle data manually. OTC prices may not match external market data."
        ))
        root.addView(scroll)
        scroll.addView(content)
        setContentView(root)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 8; bottomMargin = 8 }

    private fun startConsent() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureConsent.launch(manager.createScreenCaptureIntent())
    }
}
