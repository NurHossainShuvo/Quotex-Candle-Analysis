# Quotex Native Analysis (Kotlin starter project)

A privacy-first Android starter project for user-authorized screen capture and manual OHLC analysis.

## Included
- Explicit Android MediaProjection consent prompt on every capture session.
- Visible foreground notification while screen capture is active.
- Start/Stop controls and capture lifecycle cleanup.
- Local-only pixel sampling (no network permissions, no uploads).
- Manual OHLC CSV input with validation, EMA 9/21, RSI 14, recent support/resistance, candle shape and simple patterns.
- Experimental screen-color hint, explicitly labelled as unreliable.

## Important limitations
- This starter does NOT automatically reconstruct true OHLC from Quotex pixels. Candle geometry requires chart-region selection, scale calibration, candle segmentation, and OCR/vision validation; pixel color alone is not enough.
- Android may show a system privacy indicator and can stop projection at any time.
- Some apps may block or obscure capture. Never attempt to bypass platform restrictions.
- No trading automation, broker login, session-cookie access, or order placement is included.
- No Internet permission is declared. All processing stays on-device.

## Open and build
1. Install Android Studio (recent stable version).
2. Open this folder as a project.
3. Let Gradle sync (Android Gradle Plugin 8.7.3, Kotlin 2.0.21).
4. Build > Build APK(s), then install the debug APK on your own Android device.
5. Tap **Start capture**, accept Android's system consent prompt, then switch to the chart. Tap Stop from the app notification or return to the app and tap Stop.
6. Paste one candle per line into OHLC box in this format: `open,high,low,close` (oldest first). Example:
   `1.0810,1.0820,1.0800,1.0815`

## Data safety
Captured frames are sampled in memory and discarded. They are not saved or transmitted. The app intentionally has no network permission.


## Build APK online from a phone (GitHub Actions)
A workflow is included at `.github/workflows/android.yml`.
1. Create a GitHub repository and upload the *contents* of this project (not the ZIP itself).
2. Ensure `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/` are at repository root.
3. Open the repository's Actions tab. If prompted, enable Actions.
4. Select **Build Android APK** → **Run workflow** (or push to `main`).
5. Open the completed run, scroll to **Artifacts**, and download `QuotexAnalysis-debug-apk`.
6. Extract the downloaded artifact ZIP, then install the APK. Android may ask permission to install apps from that browser/file manager.
Use a private repository if you do not want the source publicly visible. Never upload passwords, Quotex login data, cookies, or API keys.
